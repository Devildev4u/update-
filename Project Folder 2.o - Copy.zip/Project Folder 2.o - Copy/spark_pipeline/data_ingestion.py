import os
from pyspark.sql import SparkSession
import logging

def load_data():
    logging.info("Creating Spark session...")
    spark = SparkSession.builder.appName("PowerliftingDataAnalysis").getOrCreate()

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    file1 = os.path.join(base_dir, "data", "openpowerlifting.csv")
    file2 = os.path.join(base_dir, "data", "meets.csv")

    logging.info(f"Loading datasets: {file1}, {file2}")

    df1 = spark.read.csv(file1, header=True, inferSchema=True)
    df2 = spark.read.csv(file2, header=True, inferSchema=True)

    return df1, df2
