# Big Data Analytics with PySpark

## Setup
1. Install dependencies:  

2. Run the project:  

## Features
- Data ingestion using Spark
- Feature engineering with VectorAssembler
- Machine learning using Spark MLlib
- Data visualization using Matplotlib
