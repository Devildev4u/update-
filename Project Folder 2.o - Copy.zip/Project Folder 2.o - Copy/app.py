from flask import Flask, render_template, jsonify
import subprocess
import threading

app = Flask(__name__)
output_logs = []

def run_pipeline():
    global output_logs
    process = subprocess.Popen(
        ["python", "spark_pipeline/main.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )
    output_logs.clear()
    for line in process.stdout:
        output_logs.append(line)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/start_pipeline", methods=["POST"])
def start_pipeline():
    thread = threading.Thread(target=run_pipeline)
    thread.start()
    return jsonify({"status": "Pipeline started"})

@app.route("/get_output")
def get_output():
    return jsonify(output_logs)

if __name__ == "__main__":
    app.run(debug=True)